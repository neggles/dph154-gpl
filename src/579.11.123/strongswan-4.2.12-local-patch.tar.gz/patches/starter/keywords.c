/* C code produced by gperf version 3.0.1 */
/* Command-line: /usr/local/bin/gperf -C -G -t  */
/* Computed positions: -k'1-2,$' */

#if !((' ' == 32) && ('!' == 33) && ('"' == 34) && ('#' == 35) \
      && ('%' == 37) && ('&' == 38) && ('\'' == 39) && ('(' == 40) \
      && (')' == 41) && ('*' == 42) && ('+' == 43) && (',' == 44) \
      && ('-' == 45) && ('.' == 46) && ('/' == 47) && ('0' == 48) \
      && ('1' == 49) && ('2' == 50) && ('3' == 51) && ('4' == 52) \
      && ('5' == 53) && ('6' == 54) && ('7' == 55) && ('8' == 56) \
      && ('9' == 57) && (':' == 58) && (';' == 59) && ('<' == 60) \
      && ('=' == 61) && ('>' == 62) && ('?' == 63) && ('A' == 65) \
      && ('B' == 66) && ('C' == 67) && ('D' == 68) && ('E' == 69) \
      && ('F' == 70) && ('G' == 71) && ('H' == 72) && ('I' == 73) \
      && ('J' == 74) && ('K' == 75) && ('L' == 76) && ('M' == 77) \
      && ('N' == 78) && ('O' == 79) && ('P' == 80) && ('Q' == 81) \
      && ('R' == 82) && ('S' == 83) && ('T' == 84) && ('U' == 85) \
      && ('V' == 86) && ('W' == 87) && ('X' == 88) && ('Y' == 89) \
      && ('Z' == 90) && ('[' == 91) && ('\\' == 92) && (']' == 93) \
      && ('^' == 94) && ('_' == 95) && ('a' == 97) && ('b' == 98) \
      && ('c' == 99) && ('d' == 100) && ('e' == 101) && ('f' == 102) \
      && ('g' == 103) && ('h' == 104) && ('i' == 105) && ('j' == 106) \
      && ('k' == 107) && ('l' == 108) && ('m' == 109) && ('n' == 110) \
      && ('o' == 111) && ('p' == 112) && ('q' == 113) && ('r' == 114) \
      && ('s' == 115) && ('t' == 116) && ('u' == 117) && ('v' == 118) \
      && ('w' == 119) && ('x' == 120) && ('y' == 121) && ('z' == 122) \
      && ('{' == 123) && ('|' == 124) && ('}' == 125) && ('~' == 126))
/* The character set is not based on ISO-646.  */
error "gperf generated tables don't work with this execution character set. Please report a bug to <bug-gnu-gperf@gnu.org>."
#endif


/* strongSwan keywords
 * Copyright (C) 2005 Andreas Steffen
 * Hochschule fuer Technik Rapperswil, Switzerland
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.  See <http://www.fsf.org/copyleft/gpl.txt>.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * RCSID $Id: patches/starter/keywords.c 1.4 2009/10/12 16:28:15BST Stuart Haslam (sh6) Exp  $
 * Modified by ip.access ltd 
 * Copyright (c) 2009 ip.access ltd 
 */

#include <string.h>

#include "keywords.h"

struct kw_entry {
    char *name;
    kw_token_t token;
};

#define TOTAL_KEYWORDS 106
#define MIN_WORD_LENGTH 3
#define MAX_WORD_LENGTH 18
#define MIN_HASH_VALUE 11
#define MAX_HASH_VALUE 243
/* maximum key range = 233, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
hash (str, len)
     register const char *str;
     register unsigned int len;
{
  static const unsigned char asso_values[] =
    {
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244,  60,
       45, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 110, 244,   5,
      100,   5,  70,  55,  95,   0, 244,  60,  10,  50,
       80,  55,  15, 244,   0,  50,  35,  15,  90,   0,
        0,  75,   0, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244, 244, 244, 244, 244,
      244, 244, 244, 244, 244, 244
    };
  return len + asso_values[(unsigned char)str[1]] + asso_values[(unsigned char)str[0]] + asso_values[(unsigned char)str[len - 1]];
}

static const struct kw_entry wordlist[] =
  {
    {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
    {""}, {""},
    {"crluri",            KW_CRLURI},
    {""}, {""},
    {"rekeyfuzz",         KW_REKEYFUZZ},
    {""}, {""}, {""}, {""}, {""}, {""},
    {"retransmit_timer",  KW_RETRANSMIT_TIMER},
    {""},
    {"rightfirewall",     KW_RIGHTFIREWALL},
    {""},
    {"rightnatip",        KW_RIGHTNATIP},
    {"certuribase",       KW_CERTURIBASE},
    {"rightnexthop",      KW_RIGHTNEXTHOP},
    {"rightsourceip",     KW_RIGHTSOURCEIP},
    {""}, {""},
    {"crlcheckinterval",  KW_CRLCHECKINTERVAL},
    {""}, {""}, {""}, {""}, {""},
    {"leftfirewall",      KW_LEFTFIREWALL},
    {""},
    {"leftnatip",         KW_LEFTNATIP},
    {"right",             KW_RIGHT},
    {"leftnexthop",       KW_LEFTNEXTHOP},
    {"leftsourceip",      KW_LEFTSOURCEIP},
    {""},
    {"rightcert",         KW_RIGHTCERT},
    {""},
    {"rightsubnet",       KW_RIGHTSUBNET},
    {""},
    {"rightsendcert",     KW_RIGHTSENDCERT},
    {"rightprotoport",    KW_RIGHTPROTOPORT},
    {""}, {""}, {""}, {""},
    {"left",              KW_LEFT},
    {""},
    {"retransmit_count",  KW_RETRANSMIT_COUNT},
    {"crluri2",           KW_CRLURI2},
    {"leftcert",          KW_LEFTCERT,},
    {""},
    {"leftsubnet",        KW_LEFTSUBNET},
    {"rightgroups",       KW_RIGHTGROUPS},
    {"leftsendcert",      KW_LEFTSENDCERT},
    {"leftprotoport",     KW_LEFTPROTOPORT},
    {""},
    {"righthostaccess",   KW_RIGHTHOSTACCESS},
    {""},
    {"ocspuri",           KW_OCSPURI},
    {"ike",               KW_IKE},
    {""},
    {"plutostart",        KW_PLUTOSTART},
    {""},
    {"crluri1",           KW_CRLURI},
    {"esp",               KW_ESP},
    {""},
    {"leftgroups",        KW_LEFTGROUPS},
    {"ikelifetime",       KW_IKELIFETIME},
    {"keylife",           KW_KEYLIFE},
    {"prepluto",          KW_PREPLUTO},
    {"lefthostaccess",    KW_LEFTHOSTACCESS},
    {"keep_alive",        KW_KEEP_ALIVE},
    {"keyexchange",       KW_KEYEXCHANGE},
    {""},
    {"ike_dscp",          KW_IKE_DSCP},
    {""},
    {"rekey",             KW_REKEY},
    {""}, {""},
    {"rightallowany",     KW_RIGHTALLOWANY},
    {"rightrsasigkey",    KW_RIGHTRSASIGKEY},
    {"plutodebug",        KW_PLUTODEBUG},
    {"rightupdown",       KW_RIGHTUPDOWN},
    {"pkcs11module",      KW_PKCS11MODULE},
    {"fragicmp",          KW_FRAGICMP},
    {"plutostderrlog",    KW_PLUTOSTDERRLOG},
    {"pkcs11keepstate",   KW_PKCS11KEEPSTATE},
    {"rekeymargin",       KW_REKEYMARGIN},
    {"rightsubnetwithin", KW_RIGHTSUBNETWITHIN},
    {""}, {""}, {""}, {""},
    {"leftallowany",      KW_LEFTALLOWANY},
    {"leftrsasigkey",     KW_LEFTRSASIGKEY},
    {""},
    {"leftupdown",        KW_LEFTUPDOWN},
    {"reauth",            KW_REAUTH},
    {"rightid",           KW_RIGHTID},
    {"pfsgroup",          KW_PFSGROUP},
    {""},
    {"virtual_private",   KW_VIRTUAL_PRIVATE},
    {"leftsubnetwithin",  KW_LEFTSUBNETWITHIN},
    {""},
    {"ocspuri2",          KW_OCSPURI2},
    {""}, {""},
    {"mobike",	           KW_MOBIKE},
    {"rightca",           KW_RIGHTCA},
    {"compress",          KW_COMPRESS},
    {"type",              KW_TYPE},
    {""},
    {"leftid",            KW_LEFTID},
    {"dumpdir",           KW_DUMPDIR},
    {"ldapbase",          KW_LDAPBASE},
    {""}, {""},
    {"keyingtries",       KW_KEYINGTRIES},
    {""},
    {"ocspuri1",          KW_OCSPURI},
    {""}, {""},
    {"leftca",            KW_LEFTCA},
    {""},
    {"eap",               KW_EAP},
    {"postpluto",         KW_POSTPLUTO},
    {"klipsdebug",        KW_KLIPSDEBUG},
    {""}, {""},
    {"pfs",               KW_PFS},
    {"pkcs11initargs",    KW_PKCS11INITARGS},
    {"interfaces",        KW_INTERFACES},
    {"mediated_by",       KW_MEDIATED_BY},
    {""}, {""},
    {"mediation",         KW_MEDIATION},
    {"force_keepalive",   KW_FORCE_KEEPALIVE},
    {"charonstart",       KW_CHARONSTART},
    {""}, {""}, {""}, {""}, {""},
    {"hidetos",           KW_HIDETOS},
    {"ldaphost",          KW_LDAPHOST},
    {"uniqueids",         KW_UNIQUEIDS},
    {""},
    {"cacert",            KW_CACERT},
    {""}, {""}, {""},
    {"dpdtimeout",        KW_DPDTIMEOUT},
    {"pkcs11proxy",       KW_PKCS11PROXY},
    {""}, {""},
    {"me_peerid",         KW_ME_PEERID},
    {""},
    {"charondebug",       KW_CHARONDEBUG},
    {""},
    {"installpolicy",     KW_INSTALLPOLICY},
    {""},
    {"modeconfig",        KW_MODECONFIG},
    {"overridemtu",       KW_OVERRIDEMTU},
    {""},
    {"packetdefault",     KW_PACKETDEFAULT},
    {"cachecrls",         KW_CACHECRLS},
    {"strictcrlpolicy",   KW_STRICTCRLPOLICY},
    {""}, {""}, {""},
    {"also",              KW_ALSO},
    {""}, {""}, {""}, {""},
    {"auto",              KW_AUTO},
    {""},
    {"forceencaps",       KW_FORCEENCAPS},
    {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
    {""}, {""},
    {"dpddelay",          KW_DPDDELAY},
    {""}, {""}, {""},
    {"eap_identity",      KW_EAP_IDENTITY},
    {""},
    {"dpdaction",         KW_DPDACTION},
    {""},
    {"authby",            KW_AUTHBY},
    {""},
    {"anti_replay_window",KW_ANTI_REPLAY_WINDOW},
    {""},
    {"xauth",             KW_XAUTH},
    {""}, {""},
    {"nat_traversal",     KW_NAT_TRAVERSAL},
    {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
    {""},
    {"auth",              KW_AUTH},
    {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
    {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
    {"nocrsend",          KW_NOCRSEND}
  };

#ifdef __GNUC__
__inline
#endif
const struct kw_entry *
in_word_set (str, len)
     register const char *str;
     register unsigned int len;
{
  if (len <= MAX_WORD_LENGTH && len >= MIN_WORD_LENGTH)
    {
      register int key = hash (str, len);

      if (key <= MAX_HASH_VALUE && key >= 0)
        {
          register const char *s = wordlist[key].name;

          if (*str == *s && !strcmp (str + 1, s + 1))
            return &wordlist[key];
        }
    }
  return 0;
}
