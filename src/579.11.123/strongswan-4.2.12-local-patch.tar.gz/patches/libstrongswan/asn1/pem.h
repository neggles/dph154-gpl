/*
 * Copyright (C) 2001-2008 Andreas Steffen
 *
 * Hochschule fuer Technik Rapperswil
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.  See <http://www.fsf.org/copyleft/gpl.txt>.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * Modified by ip.access ltd 
 * Copyright (c) 2009 ip.access ltd 
 * $Id: patches/libstrongswan/asn1/pem.h 1.3 2009/05/20 12:54:33BST Mark Powell (mp3) Exp  $
 */

#ifndef PEM_H_
#define PEM_H_

#include <stdio.h>

#include <library.h>

bool pem_to_bin(chunk_t *blob, chunk_t *passphrase, bool *pgp);

bool pem_asn1_load_file(char *filename, chunk_t *passphrase,
						chunk_t *blob, bool *pgp);

bool pem_asn1_load_chunk(chunk_t *passphrase,
						chunk_t *blob, bool *pgp);
#endif /*PEM_H_ @} */
