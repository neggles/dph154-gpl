#!/bin/bash
#
# Shell script to untar and build cpdump for ARM and then produce an iPkg
#
# Copyright (c) 2007 ip.access Ltd
# 

# Increment this for each IPA change
IPAVER=2

DESTDIR=$(cd ../../../../buildSupport; pwd)


# Untar and build libpcap
echo "Untarring... libpcap..."
tar -xzf libpcap-0.9.8.tar.gz

cd libpcap-0.9.8
echo "Copying the IPA diffs..."
cp -f ../ipa-diff/configure_libpcap configure
echo "Running ./configure for libpcap..."
./configure --host=arm-none-linux-gnueabi --target=arm-none-linux-gnueabi --build=i686-linux --with-pcap=linux > /dev/null
echo "Calling make on libpcap..."
make > /dev/null
# Make a shared library from the .a file
echo "Creating a .so for libpcap..."
arm-none-linux-gnueabi-gcc -shared -Wl,-soname,libpcap.so.1 -o libpcap.so.1.0 *.o
echo "Stripping libpcap..."
arm-none-linux-gnueabi-strip libpcap.so.1.0
cd ..

# Untar and build tcpdump
echo "Untarring... tcpdump..."
tar -xzf tcpdump-3.9.8.tar.gz
cd tcpdump-3.9.8

echo "Copying the IPA diffs..."
cp ../ipa-diff/configure_tcpdump configure
echo "Running ./configure for tcpdump..."
./configure --host=arm-none-linux-gnueabi --target=arm-none-linux-gnueabi --build=i686-linux > /dev/null
# Copy the Makefile again since it gets overwritten by the ./configure script! (maybe we don't need to call ./configure anyway!)
cp ../ipa-diff/Makefile_tcpdump Makefile
echo "Calling make on tcpdump..."
make > /dev/null
echo "Stripping tcpdump..."
arm-none-linux-gnueabi-strip tcpdump

###
# Now create an ipkg of the scripts & binaries
##
echo "Copying sources for iPkg..."
cd ..
mkdir -p ipkg/CONTROL/
mkdir -p ipkg/bin
mkdir -p ipkg/lib
mkdir -p ipkg/usr/share/doc/libpcap-0.9.8 
mkdir -p ipkg/usr/share/doc/tcpdump-3.9.8
cp tcpdump-3.9.8/tcpdump ipkg/bin
cp libpcap-0.9.8/libpcap.so.1.0 ipkg/lib
cp libpcap-0.9.8/LICENSE ipkg/usr/share/doc/libpcap-0.9.8/LICENSE
cp tcpdump-3.9.8/LICENSE ipkg/usr/share/doc/tcpdump-3.9.8/LICENSE

CONTROL_FILE=ipkg/CONTROL/control

echo "Package: tcpdump" > ${CONTROL_FILE} 
echo "Priority: optional" >> ${CONTROL_FILE} 
echo "Section: misc" >> ${CONTROL_FILE} 
echo "Maintainer: ip.access" >> ${CONTROL_FILE} 
echo "Architecture: arm" >> ${CONTROL_FILE} 
echo "Arch: arm" >> ${CONTROL_FILE} 
echo "Version: 3.9.8-$IPAVER" >> ${CONTROL_FILE} 
echo "Description: tcpdump" >> ${CONTROL_FILE} 
echo "Source: MKS: e:/sie/3gap/src/cpe/target/application/third_party/tcpdump" >> ${CONTROL_FILE} 

echo "Making an ipkg..."
ipkg-build -o root -g root ipkg .


echo "Copying to $DESTDIR..."
DESTDIR_IPKG=$DESTDIR/packages/common
DESTDIR_OPENSOURCE=$DESTDIR/opensource

[ -d $DESTDIR_IPKG ] || mkdir -p $DESTDIR_IPKG
[ -d $DESTDIR_OPENSOURCE ] || mkdir -p $DESTDIR_OPENSOURCE

cp -f tcpdump_3.9.8-${IPAVER}_arm.ipk ${DESTDIR_IPKG}

cp -f libpcap-0.9.8.tar.gz ${DESTDIR_OPENSOURCE}
cp -f tcpdump-3.9.8.tar.gz ${DESTDIR_OPENSOURCE}

tar czf tcpdump-libpcap-local-patch.tar.gz install.sh ipa-diff
cp -f tcpdump-libpcap-local-patch.tar.gz ${DESTDIR_OPENSOURCE}
